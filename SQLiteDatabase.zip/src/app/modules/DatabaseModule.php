<?php
namespace app\modules;

use php\gui\framework\DataUtils;
use php\lib\arr;
use php\sql\SqlResult;
use php\sql\SqlStatement;
use php\gui\framework\AbstractModule;
use php\gui\framework\ScriptEvent; 


/**
 * Модуль для работы с базой данных.
 */
class DatabaseModule extends AbstractModule
{
    /**
     * @event action 
     */
    function doAction(ScriptEvent $event = null)
    {    
        // создаем базу данных, если ее еще нет.
        $this->database->query(
            'create table if not exists users (id integer primary key, name text, nick text, age integer)'
        )->update();
    }
    
    /**
     * Возвращает список пользователей.
     * @return SqlStatement
     */
    function getUsers()
    {
        return $this->database->query('select * from users order by id desc');
    }
    
    /**
     * @return int
     */
    function getUserCount()
    {
        return (int) $this->database->query('select count(*) from users')->fetch()->get('count(*)');
    }
    
    /**
     * @return SqlResult|null
     */
    function getUser($id)
    {
        return arr::first($this->database->query('select * from users where id = ?', [$id]));
    }
    
    /**
     * Добавляет нового пользователя и возвращает его id.
     * @return int
     */
    function addUser(array $data)
    {
        $statement = $this->database->query('insert into users values(null, ?, ?, ?)', [$data['name'], $data['nick'], $data['age']]);
        $statement->update();
        
        return $statement->getLastInsertId();
    }
    
    /**
     * Сохраняет пользователя по id.
     */
    function saveUser($id, array $data)
    {
        $this->database->query('update users set name = ?, nick = ?, age = ? where id = ?', [
            $data['name'], $data['nick'], $data['age'],
            $id
        ])->update();
    }
    
    /**
     * Возвращает количество удаленных пользователей.
     * @return int
     */
    function deleteUser($id)
    {
        return $this->database->query('delete from users where id = ?', [$id])->update();
    }
    
    /**
     * Удаляет все пользователей и возвращает количество удаленных пользователей.
     * @return int 
     */
    function deleteAllUsers()
    {
        return $this->database->query('delete from users where 1 = 1')->update();
    }
}
