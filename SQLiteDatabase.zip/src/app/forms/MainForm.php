<?php
namespace app\forms;

use php\gui\UXDialog;
use php\sql\SqlStatement;
use php\sql\SqlResult;
use php\gui\framework\AbstractForm;
use php\gui\event\UXEvent; 
use php\gui\event\UXMouseEvent; 


class MainForm extends AbstractForm
{
    /**
     * @event showing 
     */
    function doShowing(UXEvent $event = null)
    {    
        $this->reloadUsers();
    }

    /**
     * @event addButton.action 
     */
    function doAddButtonAction(UXEvent $event = null)
    {    
        $userForm = app()->getNewForm('UserForm');
        $userForm->showAndWait();
        $this->reloadUsers();
        $this->table->selectedIndex = 0;
    }

    /**
     * @event editButton.action 
     */
    function doEditButtonAction(UXEvent $event = null)
    {    
        $userForm = app()->getNewForm('UserForm');
        $userForm->id = $this->table->selectedItem['id'];
        
        $userForm->showAndWait();
        
        $index = $this->table->selectedIndex;
        $this->reloadUsers();
        $this->table->selectedIndex = $index;
    }
    
    /**
     * @event deleteButton.action 
     */
    function doDeleteButtonAction(UXEvent $event = null)
    {    
        if (UXDialog::confirm('Вы уверены, что хотите удалить пользователя?')) {
            $this->deleteUser($this->table->selectedItem['id']);
            
            $index = $this->table->selectedIndex;
            
            $this->reloadUsers();
            
            $this->table->selectedIndex = $index;
            
            if ($this->table->selectedIndex == -1) {
                $this->table->selectedIndex = $index - 1;
            }
        }
    }

    /**
     * @event table.click 
     */
    function doTableClick(UXMouseEvent $event = null)
    {    
        $this->deleteButton->enabled = $this->table->selectedIndex != -1;
        $this->editButton->enabled = $this->deleteButton->enabled;
    }

    /**
     * @event deleteAllButton.action 
     */
    function doDeleteAllButtonAction(UXEvent $event = null)
    {    
        if (UXDialog::confirm('Вы уверены, что хотите удалить всех пользователей?')) {
            $this->deleteAllUsers();
            $this->reloadUsers();
        }
    }

    /**
     * @event table.mouseDown-2x 
     */
    function doTableMouseDown2x(UXMouseEvent $event = null)
    {    
        $this->doEditButtonAction();
    }

    
    /**
     * Добавляет пользователя из базы в ui таблицу.
     */
    public function addUserToTable(SqlResult $record)
    {
        $this->table->items->add($record->toArray());
    }
    
    /**
     * Добавляет сразу всех пользователей в таблицу.
     */
    public function addUsersToTable(SqlStatement $records)
    {
        foreach ($records as $record) {
            $this->addUserToTable($record);
        }
    }
    
    /**
     * Перезагружает пользователей в таблицу.
     */
    public function reloadUsers()
    {
        $this->table->items->clear();
        
        $users = $this->getUsers();
        $this->addUsersToTable($users);
        
        $count = $this->getUserCount();
        $this->countLabel->text = $count . " - Количество пользователей";
        
        $this->deleteAllButton->enabled = $count > 0;
        
        if ($count == 0) {
            $this->deleteButton->enabled = false;
            $this->editButton->enabled = false;
        }
    }
}
