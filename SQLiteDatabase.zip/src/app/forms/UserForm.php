<?php
namespace app\forms;

use php\gui\framework\AbstractForm;
use php\gui\event\UXEvent; 
use php\gui\event\UXWindowEvent; 


class UserForm extends AbstractForm
{
    /**
     * @var int
     */
    public $id;
    
    /**
     * @var string
     */
    public $name;
    
    /**
     * @var string
     */
    public $nick;
    
    /**
     * @var int
     */
    public $age;

    /**
     * @event ageSelect.construct 
     */
    function doAgeSelectConstruct(UXEvent $event = null)
    {    
        for ($i = 1; $i < 120; $i++) {
            $this->ageSelect->items->add($i);
        }
        
        $this->ageSelect->value = 18;
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $event = null)
    {    
        $data = [
            'name' => $this->nameEdit->text,
            'nick' => $this->nickEdit->text,
            'age'  => $this->ageSelect->value
        ];
        
        if (!$this->id) {
            $id = $this->addUser($data);
            
            app()->getMainForm()->toast("Создан новый пользователь с id = $id");
        } else {
            $this->saveUser($this->id, $data);
            
            app()->getMainForm()->toast("Данные успешно сохранены.");
        }
        
        
        $this->hide();
    }

    /**
     * @event showing 
     */
    function doShowing(UXWindowEvent $event = null)
    {    
        if ($this->id) {
            $user = $this->getUser($this->id);
            
            if ($user) {
                $this->name = $user->get('name');
                $this->nick = $user->get('nick');
                $this->age  = (int) $user->get('age');
            }
        }
    
        $this->nameEdit->text = $this->name;
        $this->nickEdit->text = $this->nick;
        $this->ageSelect->value = $this->age;
    }

}
